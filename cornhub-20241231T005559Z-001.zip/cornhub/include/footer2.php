<footer class="footer-1 text-white py-4 mt-5">
    <div class="container mt-5">
        <div class="row mt-5">
            <div class="col-4">
                <h5 class="mb-3">Navigate</h5>
                <ul class="list-unstyled">
                    <li class="mb-2"><a href="ecommerce2.php" class="text-white text-decoration-none">Home</a></li>
                    <li class="mb-2"><a href="products.php" class="text-white text-decoration-none">Menu</a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-8">
                <p class="copyright">Copyright © 2024 Cornhub</p>
            </div>
            <div class="col-4">
                <p class="policy">Privacy Policy</p>
            </div>
        </div>
    </div>
</footer>